import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# load data

car_prices_df = pd.read_csv('D:\MonT6_Python\Project_Vehicle_Sales_Data\car_prices.csv')
# 1.	Đọc dữ liệu từ file ‘car_prices.csv’ và lưu vào dataframe car_prices_df.
# 2.	Sử dụng hàm head() để xem dữ liệu có trong dataframe.
# 3.	Sử dụng hàm info() để xem thống kê dữ liệu.
# 4.	Tạo một bản sao df từ dataframe car_prices_df.
# 5.	Cho biết tổng số lượng hàng bị thiếu giá trị trên mỗi cột của dataframe df.

print(car_prices_df.head())

print(car_prices_df.info())

df = car_prices_df.copy()

print(df.isnull().sum())
#6	Xử lý dữ liệu bị thiếu trên các cột phân loại:
# a.	Thêm ‘Other’ vào các hàng bị thiếu giá trị trên các cột make,model,trim,color
# b.	Thêm giá trị xuất hiện nhiều nhất vào các hàng bị thiếu trên các cột body,transmission,interior
# c.	Xóa những hàng bị thiếu giá trị trên các cột vin,saledate
# column_replace= ['make', 'model', 'trim', 'color']
# df = df[column_replace].replace('Other', np.nan)
# column_replace= ['make', 'model', 'trim', 'color']
df.make.fillna('Other', inplace=True)
df.model.fillna('Other', inplace=True)
df.trim.fillna('Other', inplace=True)
df.color.fillna('Other', inplace=True)

#b
df.body.fillna(df.body.mode()[0], inplace=True)
df.transmission.fillna(df.transmission.mode()[0], inplace=True)
df.interior.fillna(df.interior.mode()[0], inplace=True)

#c
df.dropna(subset=['saledate','vin'],inplace=True)

# 7.	Xử lý dữ liệu trên các cột số:
# a.	Vẽ biểu đồ histogram của cột condition(bins = 20 và subplot(3,1,1))
# b.	Vẽ biểu đồ histogram của cột odometer(bins = 20 và subplot(3,1,2) )
# c.	Vẽ biểu đồ histogram của cột mmr(bins = 20 và subplot(3,1,3) )
# d.	Thêm giá trị trung vị của cột vào các hàng bị thiếu trên cột condition
# e.	Thêm giá trị trung bình của cột vào các hàng bị thiếu trên cột odometer
# f.	Thêm giá trị trung bình của cột vào các hàng bị thiếu trên cột mmr
#a
plt.subplot(3,1,1)
plt.hist(df.condition.dropna(),bins=20, color='blue',alpha=0.7)
plt.xlabel('Condition')
plt.ylabel('Frequency')
plt.title('Distribution of Odometer')

#b
plt.subplot(3,1,2)
plt.hist(df.odometer.dropna(),bins=20, color='yellow',alpha=0.7)
plt.xlabel('Odometer')
plt.ylabel('Frequency')
plt.title('Distribution of Odometer')

#c
plt.subplot(3,1,3)
plt.hist(df.mmr.dropna(),bins=20, color='red',alpha=0.7)
plt.xlabel('MMR')
plt.ylabel('Frequency')
plt.title('Distribution of Odometer')
plt.show()
#trung vị
df.condition.fillna(df.condition.median(), inplace=True)
#trung bình
df.odometer.fillna(df.odometer.mean(), inplace=True)
df.mmr.fillna(df.mmr.mean(), inplace=True)
#8.	Sử dụng hàm duplicated() để kiểm tra sự trùng lặp giá trị. Xóa hàng trùng lặp nếu có

duplicate_rows = df[df.duplicated()]
#9.	Sử dụng hàm describer() để xem mô tả dữ liệu.
print(df.describe())

numeric_columns = df.select_dtypes(include=['int64','float64']).columns

import seaborn as sns

# Vẽ boxplot của cột 'sellingprice' để thể hiện dữ liệu ngoại lề
sns.boxplot(x=df['sellingprice'])
plt.title('Outlier Plot of Selling Price')
plt.show()
